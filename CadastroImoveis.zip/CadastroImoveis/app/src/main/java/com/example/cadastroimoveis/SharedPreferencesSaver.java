package com.example.cadastroimoveis;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.cadastroimoveis.imoveis.Casa;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class SharedPreferencesSaver {
    SharedPreferences sharedPreferences;
    Gson gson = new Gson();

    private final String NAME = "imoveis";

    public SharedPreferencesSaver(Context context) {
        this.sharedPreferences = context.getSharedPreferences("shared preferences", Context.MODE_PRIVATE);
    }

    public void saveData(ArrayList<Casa> casas) {
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        String json = this.gson.toJson(casas);
        editor.putString(this.NAME, json);
        editor.apply();
    }

    public ArrayList<Casa> loadData() {
        String json = this.sharedPreferences.getString(this.NAME, null);
        Type type = new TypeToken<ArrayList<Casa>>() {}.getType();
        ArrayList<Casa> casas = this.gson.fromJson(json, type);

        if (casas == null) {
            casas = new ArrayList<>();
        }

        return casas;
    }
}